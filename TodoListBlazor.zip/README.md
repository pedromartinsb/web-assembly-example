# Instructions
```
dotnet run
```